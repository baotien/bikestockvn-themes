=== Porto Shortcodes ===

Register shortcodes for porto ecommerce theme.

version: 1.0.0